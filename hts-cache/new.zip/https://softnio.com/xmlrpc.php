<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head profile="http://gmpg.org/xfn/11">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>403 - FORBIDDEN</title>

				<!-- Add Slide Outs -->
				<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>        
				<script src="/cgi-sys/js/simple-expand.min.js"></script>
        
        <style type="text/css">
        body{padding:0;margin:0;font-family:helvetica;}
        #container{margin:20px auto;width:868px;}
        #container #top403{background-image:url('/cgi-sys/images/404top_w.jpg');background-repeat:no-repeat;width:868px;height:168px;}
        #container #mid403{background-image:url('/cgi-sys/images/404mid.gif');background-repeat:repeat-y;width:868px;}
        #container #mid403 #gatorbottom{position:relative;left:39px;float:left;}
        #container #mid403 #xxx{float:left;padding:30px 360px 10px; margin: auto auto -10px auto}
        #container #mid403 #content{float:left;text-align:center;width:868px;}
        #container #mid403 #content #errorcode{font-size:30px;font-weight:800;}
        #container #mid403 #content #banner{margin:20px 0 0 ;}
        #container #mid403 #content #hostedby{font-weight:800;font-size:25px;font-style:italic;margin:20px 0 0;}
        #container #mid403 #content #coupon{color:#AB0000;font-size:22px;font-style:italic;}
        #container #mid403 #content #getstarted a{color:#AB0000;font-size:31px;font-style:italic;font-weight:800;}
        #container #mid403 #content #getstarted {margin:0 0 35px;}
        #container #bottom403{background-image:url('/cgi-sys/images/404bottom.gif');background-repeat:no-repeat;width:868px;height:14px;}
        #container #mid403 #content #faq_container {margin: 5px 0 5px 0; padding: 10px 0 10px 0; clear:both;}
        #container #mid403 #content #accordion{font-size: 90%; width: 650px; min-height: 100px; margin: 0 auto; text-align: center;}
        #container #mid403 #content #accordion ul {text-align: left;}
        #container #mid403 #content #accordion ol {text-align: left;}
        #container #mid403 #content #accordion li {font-size: 90%;}
        #container #mid403 #content #accordion p {font-size: 95%; text-align: left;}
        #container #mid403 #content #accordion h3 {font-weight: bold;}
		  #container #mid403 #content #accordion h4 {font-weight: bold; font-style: italic; text-align: left;}
		  .content {display:none;}
		  .first {color: #ff6600;}
		  .second {color: #3b5998;}
		  .third {color: #198c19;}
		  .code { background-color: #e5e5e5; border: 2px solid #ede1d1; padding: 5px 5px 5px 5px; text-align: left;}
		  .shell{border: 2px solid gray; background-color: black; color: white; text-align: left;}
        </style>
        
</head>
<body>
<div id="container">
        <div id="top403"></div>
        <div id="mid403">
                <div id="xxx"><img src="/cgi-sys/images/f.png" alt="" /></div>
        <div id="content">
            <div id="errorcode">ERROR 403 - FORBIDDEN</div>
              <div id="faq_container">
					 <div id="accordion">
					 	<div id="why">
						 <h3><a class="expander" href=#>Why am I seeing this page?</a></h3>
							<div class="content">
									<p>403 errors usually mean that the server does not have permission to view the requested file or resource.These errors are often caused by IP Deny rules, File protections, or permission problems.</p>
									<p>In many cases this is not an indication of an actual problem with the server itself but rather a problem with the information the server has been instructed to access as a result of the request. This error is often caused by an issue on your site which may require additional review by our support teams.</p>
									<p>Our support staff will be happy to assist you in resolving this issue. Please contact our Live Support or reply to any Tickets you may have received from our technicians for further assistance.</p>
							</div>
						</div>
						<div id="what_to_do">
						<h3><a class="expander" href=#>Is there anything that I can do?</a></h3>
							<div class="content">
								<p>There are a few common causes for this error code including problems with the individual script that may be executed upon request. Some of these are easier to spot and correct than others.</p>
								<h4><u>File and Directory Ownership</u></h4>
								<p>The server you are on runs applications in a very specific way in most cases. The server generally expects files and directories be owned by your specific user <strong>cPanel user</strong>. If you have made changes to the file ownership on your own through SSH please reset the Owner and Group appropriately.</p>
								<h4><u>File and Directory Permissions</u></h4>
								<p>The server you are on runs applications in a very specific way in most cases. The server generally expects files such as HTML, Images, and other media to have a permission mode of <strong>644</strong>. The server also expects the permission mode on directories to be set to <strong>755</strong> in most cases.</p>
								<p><strong>(See the Section on Understanding Filesystem Permissions.)</strong></p>
								<p><strong>Note:</strong> If the permissions are set to <strong>000</strong>, please contact our support team using the ticket system. This may be related to an account level suspension as a result of abuse or a violation of our Terms of Service.</p>
								<h4><u>IP Deny Rules</u></h4>
								<p>In the .htaccess file, there may be rules that are conflicting with each other or that are not allowing an IP address access to the site.</p>
								<p>If you would like to check a specific rule in your .htaccess file you can comment that specific line in the .htaccess by adding # to the beginning of the line. You should always make a backup of this file before you start making changes.</p>
								<p>For example, if the .htaccess looks like</p>
								<div class="code">
									Order deny,allow<br />
									allow from all<br />
									deny from 192.168.1.5<br />
									deny from 192.168.1.25
								</div>
								<p>Then try something like this</p>
								<div class="code">
									Order allow,deny<br />
									allow from all<br />
									#deny from 192.168.1.5<br />
									deny from 192.168.1.25
								</div>
								<p>Our server administrators will be able to advise you on how to avoid this error if it is caused by process limitations. Please contact our Live Support or open a Ticket. Be sure to include the steps needed for our support staff to see the 403 error on your site.</p>
							</div>
						</div>
						<div id="understand_perms">
						<h3><a class="expander" href=#>Understanding Filesystem Permissions</a></h3>
							<div class="content">						
								<h4><u>Symbolic Representation</u></h4>
								<p>The <strong>first character</strong> indicates the file type and is not related to permissions. The remaining nine characters are in three sets, each representing a class of permissions as three characters. The <strong><span class="first">first set</span></strong> represents the user class. The <strong><span class="second">second set</span></strong> represents the group class. The <strong><span class="third">third set</span></strong> represents the others class.</p>
								<p>Each of the three characters represent the read, write, and execute permissions:</p>
									<ul>
										<li><strong>r</strong> if reading is permitted, <strong>-</strong> if it is not.</li>
										<li><strong>w</strong> if writing is permitted, <strong>-</strong> if it is not.</li>
										<li><strong>x</strong> if execution is permitted, <strong>-</strong> if it is not.</li>
									</ul>
								<p>The following are some examples of symbolic notation:</p>
									<ul>
										<li><strong>-<span class="first">rwx</span><span class="second">r-x</span><span class="third">r-x</span></strong> a regular file whose user class has full permissions and whose group and others classes have only the read and execute permissions.</li>
										<li><strong>c<span class="first">rw-</span><span class="second">rw-</span><span class="third">r--</span></strong> a character special file whose user and group classes have the read and write permissions and whose others class has only the read permission.</li>
										<li><strong>d<span class="first">r-x</span><span class="second">---</span><span class="third">---</span></strong> a directory whose user class has read and execute permissions and whose group and others classes have no permissions.</li>
									</ul>
								<h4><u>Numeric Representation</u></h4>
								<p>Another method for representing permissions is an octal (base-8) notation as shown. This notation consists of at least three digits. Each of the three rightmost digits represents a different component of the permissions: <strong><span class="first">user</span></strong>, <strong><span class="second">group</span></strong>, and <strong><span class="third">others</span></strong>.</p>
								<p>Each of these digits is the sum of its component bits As a result, specific bits add to the sum as it is represented by a numeral:</p>
									<ul>
										<li>The read bit adds 4 to its total (in binary 100),</li>
										<li>The write bit adds 2 to its total (in binary 010), and</li>
										<li>The execute bit adds 1 to its total (in binary 001).</li>
									</ul>
									<p>These values never produce ambiguous combinations. each sum represents a specific set of permissions. More technically, this is an octal representation of a bit field – each bit references a separate permission, and grouping 3 bits at a time in octal corresponds to grouping these permissions by <strong><span class="first">user</span></strong>, <strong><span class="second">group</span></strong>, and <strong><span class="third">others</span></strong>.</p>
									<p><strong>Permission mode 0<span class="first">7</span><span class="second">5</span><span class="third">5</span></strong></p>
										<dl class="code">
											<dt><strong><span class="first">4+2+1=7</span></strong>
												<dd>Read, Write, eXecute</dd>
											</dt>
											<dt><strong><span class="second">4+1=5</span></strong>
												<dd>Read, eXecute</dd>
											</dt>
											<dt><strong><span class="third">4+1=5</span></strong>
												<dd>Read, eXecute</dd>
											</dt>
										</dl>
									<p><strong>Permission mode 0<span class="first">6</span><span class="second">4</span><span class="third">4</span></strong></p>
										<dl class="code">
											<dt><strong><span class="first">4+2=6</span></strong>
												<dd>Read, Write</dd>
											</dt>
											<dt><strong><span class="second">4</span></strong>
												<dd>Read</dd>
											</dt>
											<dt><strong><span class="third">4</span></strong>
												<dd>Read</dd>
											</dt>
										</dl>	
							</div>
						</div>
						<div id="edit_access">
						<h3><a class="expander" href=#>How to modify your .htaccess file</a></h3>
							<div class="content">
								<p>The .htaccess file contains directives (instructions) that tell the server how to behave in certain scenarios and directly affect how your website functions.</p>
								<p>Redirects and rewriting URLs are two very common directives found in a .htaccess file, and many scripts such as WordPress, Drupal, Joomla and Magento add directives to the .htaccess so those scripts can function.</p>
								<p>It is possible that you may need to edit the .htaccess file at some point, for various reasons.This section covers how to edit the file in cPanel, but not what may need to be changed.(You may need to consult other articles and resources for that information.)</p>
								<h4><u>There are Many Ways to Edit a .htaccess File</u></h4>
									<ul>
										<li>Edit the file on your computer and upload it to the server via FTP</li>
										<li>Use an FTP program's Edit Mode</li>
										<li>Use SSH and a text editor</li>
										<li>Use the File Manager in cPanel</li>
									</ul>
								<p>The easiest way to edit a .htaccess file for most people is through the File Manager in cPanel.</p>
								<h4><u>How to Edit .htaccess files in cPanel's File Manager</u></h4>
								<p>Before you do anything, it is suggested that you backup your website so that you can revert back to a previous version if something goes wrong.</p>
								<h4><u>Open the File Manager</u></h4>
								<ol>
									<li>Log into cPanel.</li>
									<li>In the Files section, click on the <strong>File Manager</strong> icon.</li>
									<li>Check the box for&nbsp;<strong>Document Root for</strong> and select the domain name you wish to access from the drop-down menu.</li>
									<li>Make sure&nbsp;<strong>Show Hidden Files (dotfiles)</strong>" is checked.</li>
									<li>Click&nbsp;<strong>Go</strong>. The File Manager will open in a new tab or window.</li>
									<li>Look for the .htaccess file in the list of files. You may need to scroll to find it.</li>
								</ol>
								<h4><u>To Edit the .htaccess File</u></h4>
								<ol>
									<li>Right click on the <strong>.htaccess file</strong> and click&nbsp;<strong>Code Edit</strong> from the menu. Alternatively, you can click on the icon for the .htaccess file and then click on the <strong>Code Editor</strong> icon at the top of the page.</li>
									<li>A dialogue box may appear asking you about encoding. Just click&nbsp;<strong>Edit</strong> to continue. The editor will open in a new window.</li>
									<li>Edit the file as needed.</li>
									<li>Click&nbsp;<strong>Save Changes</strong> in the upper right hand corner when done. The changes will be saved.</li>
									<li>Test your website to make sure your changes were successfully saved. If not, correct the error or revert back to the previous version until your site works again.</li>
									<li>Once complete, you can click&nbsp;<strong>Close</strong> to close the File Manager window.</li>
								</ol>
							</div>
						</div>
						<div id="edit_permissions">
						<h3><a class="expander" href=#>How to modify file and directory permissions</a></h3>
							<div class="content">
								<p>The permissions on a file or directory tell the server how in what ways it should be able to interact with a file or directory.</p>
								<p>This section covers how to edit the file permissions in cPanel, but not what may need to be changed.(See the section on what you can do for more information.)</p>
								<h4><u>There are Many Ways to Edit a File Permissions</u></h4>
									<ul>
										<li>Use an FTP program</li>
										<li>Use SSH and a text editor</li>
										<li>Use the File Manager in cPanel</li>
									</ul>
								<p>The easiest way to edit file permissions for most people is through the File Manager in cPanel.</p>
								<h4><u>How to Edit file permissions in cPanel's File Manager</u></h4>
								<p>Before you do anything, it is suggested that you backup your website so that you can revert back to a previous version if something goes wrong.</p>
								<h4><u>Open the File Manager</u></h4>
								<ol>
									<li>Log into cPanel.</li>
									<li>In the Files section, click on the <strong>File Manager</strong> icon.</li>
									<li>Check the box for&nbsp;<strong>Document Root for</strong> and select the domain name you wish to access from the drop-down menu.</li>
									<li>Make sure&nbsp;<strong>Show Hidden Files (dotfiles)</strong>" is checked.</li>
									<li>Click&nbsp;<strong>Go</strong>. The File Manager will open in a new tab or window.</li>
									<li>Look for the file or directory in the list of files. You may need to scroll to find it.</li>
								</ol>
								<h4><u>To Edit the Permissions</u></h4>
								<ol>
									<li>Right click on the <strong>file or directory</strong> and click&nbsp;<strong>Change Permissions</strong> from the menu.</li>
									<li>A dialogue box should appear allowing you to select the correct permissions or use the numerical value to set the correct permissions.</li>
									<li>Edit the file permissions as needed.</li>
									<li>Click&nbsp;<strong>Change Permissions</strong> in the lower left hand corner when done. The changes will be saved.</li>
									<li>Test your website to make sure your changes were successfully saved. If not, correct the error or revert back to the previous version until your site works again.</li>
									<li>Once complete, you can click&nbsp;<strong>Close</strong> to close the File Manager window.</li>
								</ol>
							</div>
						</div>
					</div>
				</div> 
        </div>

        <div style="clear:left;"></div>
        </div>
        <div id="bottom403"></div>
</div>

    <script type="text/javascript">
        $(function () {
            $('.expander').simpleexpand();
            prettyPrint();
        });
    </script>

</body>

</html>
